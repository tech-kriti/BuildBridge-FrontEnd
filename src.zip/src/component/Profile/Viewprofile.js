import React, { useEffect, useState } from 'react';
import axios from 'axios';
import styles from './Viewprofile.module.css';
import { FaEdit, FaGithub, FaLinkedin, FaGlobe } from 'react-icons/fa';
import { MdLocationOn, MdEmail, MdPhone } from 'react-icons/md';
import useAuth from '../../utils/Auth';
import Apis from '../Apis';
import { useNavigate } from 'react-router-dom';

function  ViewProfile() {
  const [users, setUser] = useState(null);
  const { token,user } = useAuth();
  const navigate = useNavigate();
  const id= user.userId;
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get(`${Apis.Get_profile}${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        console.log(res.data);
        setUser(res.data);
      } catch (err) {
        console.error('Failed to fetch profile', err);
      }
    };
    fetchUser();
  }, []);
  
  if (!users) return <div className={styles.loading}>Loading profile...</div>;



  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.avatarBox}>
          <img
            src={`http://localhost:3000${user.profile_photo}` || '/default-avatar.png'}
            alt="avatar"
            className={styles.avatar}
          />
       
        </div>
        <div className={styles.info}>
          <h2>{users.name}</h2>
          <p className={styles.bio}>{users.bio || 'No bio available.'}</p>
        </div>
      </div>

      <div className={styles.section}>
        <h3>Contact Info</h3>
        <p><MdEmail /> {users.email}</p>
        {users.contact_number && <p><MdPhone /> {users.contact_number}</p>}
        {users.location && <p><MdLocationOn /> {users.location}</p>}
      </div>

      <div className={styles.section}>
        <h3>Social Links</h3>
        <div className={styles.links}>
          {users.github && (
            <a href={users.github} target="_blank" rel="noopener noreferrer">
              <FaGithub /> GitHub
            </a>
          )}
          {users.linkedin && (
            <a href={users.linkedin} target="_blank" rel="noopener noreferrer">
              <FaLinkedin /> LinkedIn
            </a>
          )}
          {users.portfolio && (
            <a href={users.portfolio} target="_blank" rel="noopener noreferrer">
              <FaGlobe /> Portfolio
            </a>
          )}
        </div>
      </div>

      {users.resume && (
        <div className={styles.section}>
          <h3>Resume</h3>
          <a
            href={`http://localhost:3000${users.resume?.replace(/\\/g, '/')}`}
            target="_blank"
            rel="noopener noreferrer"
            className={styles.resumeBtn}
          >
            View Resume
          </a>
        </div>
      )}
    </div>
  );
};

export default ViewProfile;
