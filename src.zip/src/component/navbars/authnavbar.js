import React, { useState } from "react";
import { Navbar, Container, Nav, Form, FormControl } from "react-bootstrap";
import { FaBell, FaPlus, FaUserCircle } from "react-icons/fa";
import DropDown from "./dropdown";
import "./Navbar.css";
import { useNavigate } from 'react-router-dom';

const DashboardNavbar = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="custom-navbar">
      <Container fluid>
        <div className="d-flex align-items-center">
          <FaUserCircle className="avatar-icon" onClick={toggleDropdown} />
          <Navbar.Brand className="ms-2">ProjectCollab</Navbar.Brand>
        </div>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto w-100 justify-content-center">
            <Form className="d-flex ms-3">
              <FormControl
                type="search"
                placeholder="Search"
                className="search-bar"
              />
            </Form>
          </Nav>
          <Nav className="ms-auto align-items-center">
            <FaPlus className="icon" title="Add Project" onClick={() => navigate('/home/add-project')} />
            <FaBell className="icon" title="Notifications" onClick={() => navigate('/home/notifications')} />
          </Nav>
        </Navbar.Collapse>
      </Container>

      {dropdownOpen && (
        <div className="dropdown-container">
          <DropDown />
        </div>
      )}
    </Navbar>
  );
};

export default DashboardNavbar;
