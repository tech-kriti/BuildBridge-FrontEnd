import { Link, useNavigate } from "react-router-dom";
import "./Navbar.css"
import { FaBell, FaPlus, FaUserCircle, FaEdit } from "react-icons/fa";

function DropDown(){
    const navigate = useNavigate();
    return<>
       <div className="avatar-dropdown">
                             <div className="profile-section">
                                 <div className="avatar-container">
                                     <img src="https://media.istockphoto.com/id/1437816897/photo/business-woman-manager-or-human-resources-portrait-for-career-success-company-we-are-hiring.jpg?s=612x612&w=0&k=20&c=tyLvtzutRh22j9GqSGI33Z4HpIwv9vL_MZw_xOE19NQ=" alt="Profile" className="avatar" />
                                     <FaEdit className="edit-icon" onClick={()=>navigate("/home/create-profile")} />
                                 </div>
                                 <div className="user-name">John Doe</div>
                             </div>
                             <div className="dropdown-links">
                                  <Link to ="/home/profile/:id">View Profile</Link>
                                  <Link to ="/home/add-education">Add Education</Link>
                                  <Link to ="/home/add-skill">Add skills</Link>
                                 
                                 <Link to ="/home/my-projects">My Project</Link>
                                 
                                  <a>logout</a>
                                
                             </div>
                         </div>
    </>
}
export default DropDown;