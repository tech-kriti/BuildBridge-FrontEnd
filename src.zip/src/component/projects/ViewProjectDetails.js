import { useEffect, useState } from "react";
import Apis from "../Apis";
import axios from "axios";
import useAuth, { getToken } from "../../utils/Auth";
import { useParams } from "react-router-dom";
import "./ViewProject.css"
import { FaCogs, FaComment, FaComments, FaEdit, FaSignOutAlt, FaTrash, FaUserPlus } from "react-icons/fa";

function ViewDetails() {
    const { id } = useParams();
    const [projectDetail, setProjectDetail] = useState("");
     const{token ,user}= useAuth();
    useEffect(() => {
        loaddata();
    }, []);
    let loaddata = async () => {

        try {
           
            console.log(token);
            console.log(user);
            const res = await axios.get(`${Apis.Get_projectByID}${id}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            setProjectDetail(res.data.project);

        } catch (error) {
            console.error('Error fetching projects:', error);
        }


    }
     const isCreator = (projectDetail.created_by| projectDetail.created_by?._id) === (user.userId|user._id);
     console.log(isCreator);
     console.log(projectDetail.created_by?._id)
  const isMember = projectDetail.memberships?.some(m => m.user_id === user.userId);

    return <>

          <div className="project-details-container">
      <div className="project-card-details">
        <h2 className="project-title">{projectDetail.title}</h2>
        <p className="project-description">{projectDetail.description}</p>

        <div className="project-infoo">
          <p><strong>Stack:</strong> {projectDetail.technical_stack}</p>
          <p><strong>Technologies:</strong> {projectDetail.technologies?.map(t => t.name).join(', ')}</p>
          <p><strong>Members Needed:</strong> {projectDetail.members_needed}</p>
          <p><strong>Deadline:</strong> {new Date(projectDetail.deadline).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}</p>
          <p><strong>Created By:</strong> {projectDetail.user?.name||projectDetail.created_by?.name} ({projectDetail.user?.email || projectDetail.created_by?.email})</p>
        </div>

        <div className="action-buttons">
          {isCreator ? (
            <>
              <button className="icon-btnn manage"><FaCogs /> Manage</button>
              <button className="icon-btnn edit"><FaEdit /> Edit</button>
              <button className="icon-btnn delete"><FaTrash /> Delete</button>
              <button className="icon-btnn chat"><FaComments /> Chat</button>
            </>
          ) : isMember ? (
            <>
              <button className="icon-btnn leave"><FaSignOutAlt /> Leave</button>
              <button className="icon-btnn chat"><FaComments /> Chat</button>
            </>
          ) : (
            <button className="icon-btnn request"><FaUserPlus /> Request to Join</button>
          )}
        </div>
      </div>
    </div>
    </>
}

export default ViewDetails;