export default {
    Register: "http://localhost:3000/user/register",
    Login:"http://localhost:3000/user/login",
    Get_All_Projects:"http://localhost:3000/user/",
    Get_myProject:"http://localhost:3000/user/project/my-projects",
    Get_projectByID:"http://localhost:3000/user/project/",
    Add_project:"http://localhost:3000/user/projects",
    Get_Tech:"http://localhost:3000/user/project/technology",
    Get_profile:"http://localhost:3000/user/profile/",
    Update_profile:"http://localhost:3000/user/profile",
    
  
}