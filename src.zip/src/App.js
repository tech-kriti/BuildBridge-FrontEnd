import logo from './logo.svg';
import './App.css';
import UnauthDashboard from './pages/Unauthenticate';
import { Route, Routes } from 'react-router-dom';
import Register from './component/chatboat/chatboatResgister.js';
import Login from './component/chatboat/chatboatlogin.js'
import AuthDashboard from './pages/authdashboard.js';
import PrivateRoute from './component/PrivateRoute.js';
import MyProjects from './component/projects/Myproject.js';
import Feed from './component/dashbody/body.js';
import ViewDetails from './component/projects/ViewProjectDetails.js';
import AddProject from './component/projects/Addproject.js';
import ViewProfile from './component/Profile/Viewprofile.js';
import UpdateProfile from './component/Profile/UpdateProfile.js';

function App() {
  return <>
  <Routes>
  <Route path="/" element={<UnauthDashboard/>} />
  <Route path="/register" element={<Register/>}></Route>
  <Route path="/login"element={<Login/>}></Route>
    <Route path="/home/*" element={<PrivateRoute><AuthDashboard /></PrivateRoute>}>
  <Route index element={<Feed />} />
  <Route path="my-projects" element={<MyProjects />} />
  <Route path='project/:id' element={<ViewDetails/>}/>
  <Route path='add-project' element={<AddProject/>}/>
  <Route path='profile/:id' element={<ViewProfile/>}/>
  <Route path='create-profile' element={<UpdateProfile/>}/>
</Route>
  </Routes>
   
  </>
}

export default App;
